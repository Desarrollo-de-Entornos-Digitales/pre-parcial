import Image from 'next/image';
import ChatBubble from './_components/ChatBubble';
import ListMessages from './_components/ListMessages';
import { initialChats } from '../util/chat.util';
import ContactCard from './_components/ContactCard';
import NavBar from './_components/NavBar';

export default function Home() {
    return (
        <div>
            <NavBar />
        </div>
    );
}
