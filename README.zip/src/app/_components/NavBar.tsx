"use client";

import { initialChats } from "@/src/util/chat.util";
import ContactCard from "./ContactCard";
import ListMessages from "./ListMessages";
import { useState } from "react";

export default function NavBar() {
    const [selectedChat, setSelectedChat] = useState(0);
    return (
        <div className="flex h-screen">
            <div className="bg-blue-500">
                {initialChats.map(c => <ContactCard key={c.id} contact={c} setSelectedChat={setSelectedChat} selectedChat={selectedChat} />)}
            </div>
            {selectedChat != 0 && <ListMessages contact={initialChats[selectedChat - 1]} />}

        </div>
    )
}