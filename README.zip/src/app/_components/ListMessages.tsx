"use client";

import { Contact, Message } from "@/src/util/chat.util";
import ChatBubble from "./ChatBubble";
import { useEffect, useState } from "react";

export default function ListMessages({ contact }: { contact: Contact }) {
    const [stateMessages, setStateMessages] = useState(contact.messages);
    const [currentMessage, setCurrentMessage] = useState<string | undefined>();

    const createNewMessage = () => {
        const newMessage: Message = {
            id: stateMessages.length + 1,
            text: currentMessage ?? "",
            time: new Date().toLocaleTimeString().split(" ")[0],
            sender: "me"
        }

        setStateMessages(prev => [...prev, newMessage])
    }

    useEffect(() => { setStateMessages(contact.messages) }, [contact.messages])

    return (
        <div className="w-full flex flex-col justify-between">
            <div>
                {stateMessages.map((m) => <ChatBubble key={m.id} message={m} />)}
            </div>
            <div className="flex flex-row">
                <input
                    type="text"
                    placeholder="Escribir..."
                    className="input w-full" value={currentMessage}
                    onChange={(e) => setCurrentMessage(e.target.value)}
                />
                <button className="btn btn-primary" onClick={createNewMessage}>
                    Enviar
                </button>
            </div>
        </div>
    )
}