import { Message } from "@/src/util/chat.util";

export default function ChatBubble({ message }: {message: Message}) {
    const orientation = message.sender === "me" ? "end" : "start";
    const color =  message.sender === "me" ? "primary" : "white"
    return (
        <div className={`chat chat-${orientation}`}>
            <div className={`chat-bubble chat-bubble-${color}`}>{message.text}</div>
             <div className="chat-footer opacity-50">{message.time}</div>
        </div>
    )
}