"use client";

import { Contact } from "@/src/util/chat.util";

export default function ContactCard(
    { contact, setSelectedChat, selectedChat }: { contact: Contact, setSelectedChat: (arg0: number) => void, selectedChat: number }
) {
    const nameSplit = contact.name.split(" ");
    const acronym = nameSplit[0][0] + nameSplit[1][0];
    const lastMessage = contact.messages[contact.messages.length - 1]
    const isSelected = selectedChat === contact.id; // true, false
    return (
        <div className={`flex flex-row justify-between items-center ${isSelected ? "bg-gray-400" : "bg-gray-200"} w-86 px-4 py-2`} onClick={() => setSelectedChat(contact.id)
        }>
            <div className="flex gap-2 items-center">
                <div className="avatar avatar-placeholder">
                    <div className="bg-blue-300 text-neutral-content w-12 rounded-full">
                        <span className="text-xl">{acronym}</span>
                    </div>
                </div>
                <div>
                    <h3 className="font-bold">{contact.name}</h3>
                    <h3>{lastMessage.text}</h3>
                </div>
            </div>
            <p className="m-4">{lastMessage.time}</p>
        </div >
    )
}